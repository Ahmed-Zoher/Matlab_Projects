clc
clear all
close all
variable = [0:0.01:2];
sigma2=0.5;                %scale prameters
L = 15;                    %levels
X = raylpdf(variable,sigma2); %pdf
plot(variable,X)

yk = [0:0.1:0.1*14];
xk=yk(1:L-1)+yk(2:L);
xk=xk/2;

addition=0;
dx=0.01;
yk_new=[];
for k=1:1:L-1
    if k==1
        U=-1;
    else
        U=xk(k-1);
    end
    %     for x = 1:1:length(X)
    %         addition = addition + (x*(X(x)/sum(X(find(U<X<xk(k)))))*dx);
    %
    %     end
    
    indeces=intersect(find(U<X),find(X<xk(k)));
    addition=(sum(variable(indeces).*X(indeces))*dx)/(sum(X(indeces))*dx);
    yk_new = [yk_new addition];
end